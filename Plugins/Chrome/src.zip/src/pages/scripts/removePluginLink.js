if (chrome.tabs) {
	var link = document.getElementById("pluginlink");
	link.parentNode.removeChild(link);
}